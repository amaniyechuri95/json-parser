import re

from parse_code import parse_dict
from parse_code import parse_array
from parse_code import parse_string

parse_int = int
parse_float = float

NUMBER_RE = re.compile(
            r'(-?(?:0|[1-9]\d*))(\.\d+)?([eE][-+]?\d+)?',
            (re.VERBOSE | re.MULTILINE | re.DOTALL))
match_number = NUMBER_RE.match

def _scan_once(string, idx):
    string = string.strip()

    try:
        nextchar = string[idx]
    except IndexError:
        raise StopIteration(idx) from None

    if nextchar == '"':
        return parse_string(string, idx + 1)
    elif nextchar == '{':
        return parse_dict((string, idx + 1), _scan_once)
    elif nextchar == '[':
        return parse_array((string, idx + 1), _scan_once)
    elif nextchar == 'n' and string[idx:idx + 4] == 'null':
        return None, idx + 4
    elif nextchar == 't' and string[idx:idx + 4] == 'true':
        return True, idx + 4
    elif nextchar == 'f' and string[idx:idx + 5] == 'false':
        return False, idx + 5

    m = match_number(string, idx)
    if m is not None:
        integer, frac, exp = m.groups()
        if frac or exp:
            res = parse_float(integer + (frac or '') + (exp or ''))
        else:
            res = parse_int(integer)
        return res, m.end()
