from scanner_code import _scan_once

class CustomJsonParser:
    """
    Should take a string when initializing the class, convert it to json and
    return the json object on CustomJsonParser(jsonString).parse()
    """

    jsonString = ""
    jsonParsed = {}

    def __init__(self, jsonString):
        self.jsonString = jsonString
        """
        Write yout code here
        """
        pass



    def parse(self):
        """
        Write your code here
        """
        return _scan_once(self.jsonString, 0)[0]

        """
        Dont touch the return statement, your code will be evaluated by the return value of this function
        """
        #return self.jsonParsed
