string = '{ "name": "John Doe", "age": 32, "address": ["#619, Koramangala 1st block","bangalore - 512082"], "married": False, "preferences": {"food": "veg", "beverages": ["coffee", "fanta"], "cuisine": "chinese", "smoking": False}}'

from scanner_code import _scan_once

string =     """{
                "simpleWithTabNoSpace": null
                    }
                        """
_d = """{
"ram" :
[1, "2"],
"nine"  : false}"""

import pdb; pdb.set_trace()
print(_scan_once(string, 0)[0])
