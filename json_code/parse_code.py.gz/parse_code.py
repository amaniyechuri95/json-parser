import re

FLAGS = re.VERBOSE | re.MULTILINE | re.DOTALL

WHITESPACE = re.compile(r'[ \t\n\r]*', FLAGS)
WHITESPACE_STR = ' \t\n\r'

STRINGCHUNK = re.compile(r'(.*?)(["\\\x00-\x1f])', FLAGS)

def parse_dict(s_and_end, scan_once, _w=WHITESPACE.match, _ws=WHITESPACE_STR):

    s, end = s_and_end
    pairs = []
    pairs_append = pairs.append
    memo = {}
    memo_get = memo.setdefault
    nextchar = s[end:end + 1]

    if nextchar != '"':
        if nextchar in _ws:
            end = _w(s, end).end()
            nextchar = s[end:end + 1]

        if nextchar == '}':
            pairs = {}
            return pairs, end + 1
    end += 1

    while True:
        key, end = parse_string(s, end)
        key = memo_get(key, key)

        if s[end:end + 1] != ':':
            end = _w(s, end).end()
        end += 1

        try:
            if s[end] in _ws:
                end += 1
                if s[end] in _ws:
                    end = _w(s, end + 1).end()
        except IndexError:
            pass

        value, end = scan_once(s, end)
        pairs_append((key, value))

        try:
            nextchar = s[end]
            if nextchar in _ws:
                end = _w(s, end + 1).end()
                nextchar = s[end]
        except IndexError:
            nextchar = ''
        end += 1

        if nextchar == '}':
            break

        end = _w(s, end).end()
        nextchar = s[end:end + 1]
        end += 1

    pairs = dict(pairs)
    return pairs, end

def parse_array(s_and_end, scan_once, _w=WHITESPACE.match, _ws=WHITESPACE_STR):
    s, end = s_and_end
    values = []
    nextchar = s[end:end + 1]

    if nextchar in _ws:
        end = _w(s, end + 1).end()
        nextchar = s[end:end + 1]

    if nextchar == ']':
        return values, end + 1

    _append = values.append

    while True:
        value, end = scan_once(s, end)
        _append(value)
        nextchar = s[end:end + 1]

        if nextchar in _ws:
            end = _w(s, end + 1).end()
            nextchar = s[end:end + 1]
        end += 1

        if nextchar == ']':
            break

        try:
            if s[end] in _ws:
                end += 1
                if s[end] in _ws:
                    end = _w(s, end + 1).end()
        except IndexError:
            pass

    return values, end

def parse_string(s, end, _m=STRINGCHUNK.match):

    chunks = []
    _append = chunks.append

    while 1:
        chunk = _m(s, end)
        end = chunk.end()
        content, terminator = chunk.groups()

        if content:
            _append(content)

        if terminator == '"':
            break

    return ''.join(chunks), end
